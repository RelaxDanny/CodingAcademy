# 1 이미지 파일을 화면에 표시
import cv2

img_file = "0_high.jpg" #표시할 이미지 경로
img = cv2.imread(img_file) #이미지를 읽어서 img 변수에 할당

if img is not None:
    cv2.imshow('IMG', img) #읽은 이미지를 화면에 표시
    cv2.waitKey() #키가 입력될때까지 대기
    #cv2.waitKey([delay]) delay를 0으로 놓을경우 무한대기
    #특정 키를 받을 수 있다.
    cv2.destroyAllWindows() #창 모두 닫기
else:
    print("No image file")


# 2 이미지 파일을 그레이 스케일로 화면에 표시
import cv2

img_file = "0_high.jpg"
img = cv2.imread(img_file, cv2.IMREAD_GRAYSCALE) #두번째 매개변수에는 색을 정할 수 있음

if img is not None:
    cv2.imshow('IMG', img) #읽은 이미지를 화면에 표시
    cv2.waitKey() #키가 입력될때까지 대기
    #cv2.waitKey([delay]) delay를 0으로 놓을경우 무한대기
    #특정 키를 받을 수 있다.
    cv2.destroyAllWindows() #창 모두 닫기
else:
    print("No image file")

# 3 컬러(원본) 이미지를 그레이 스케일된 이미지로 저장

import cv2

img_file = "0_high.jpg"
save_file = "new_0_high.jpg"

img = cv2.imread(img_file, cv2.IMREAD_GRAYSCALE)
cv2.imshow(img_file, img)
cv2.imwrite(save_file, img) #파일로 저장, 포맷은 확장자에 따라 달라짐
cv2.waitKey()
cv2.destroyAllWindows()

# 4 동영상 및 카메라 프레임 읽기

import cv2

video_file = 'test.avi' #동영상 파일 경로

cap = cv2.VideoCapture(video_file) #동영상 캡쳐 객체 생성
if cap.isOpened():
    while True:
        ret, img = cap.read() #다음 프레임 읽기 / img는 카메라가 보는 프레임 또는 사진 / 영상은 사진의 빠른 나열
        if ret: #ret은 카메라가 열렸는지 아닌지를 표기하는 T and F이다.
            cv2.imshow(video_file, img) #화면에 표시
            cv2.waitKey(25) #25ms지연, 40fps 정도?
        else:
            break
else:
    print("can't open video")
cap.release() #캡쳐 자원 반납 비디오 끄기
cv2.destroyAllWindows()

# 5 동영상 카메라 프레임 읽기

import cv2

cap = cv2.VideoCapture(0) #0번 카메라 장치 연결
if cap.isOpened():
    while True:
        ret, img = cap.read()
        if ret:
            cv2.imshow('camera', img)
            if cv2.waitKey(1) != -1: #1ms 동안 키 입력 대기
                break  #아무 키나 누르면 중지
        else:
            print("no cam")
            break
else:
    print("can't open camera")
cap.release()
cv2.destroyAllWindows()

